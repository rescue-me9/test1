#include "jotm.h"
#include <stdio.h>

int WorldFunction[] = {
0,//0 
0,//1 
0,//2 
0
};

int gamemode_set = 0;
