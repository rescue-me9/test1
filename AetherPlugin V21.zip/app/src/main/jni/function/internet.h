#include "jotm.h"
#include <stdio.h>

int InternetFunction[] = {
0,//0 Import
0,//1 
0,//2 
0
};
