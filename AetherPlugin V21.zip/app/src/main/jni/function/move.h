#include "jotm.h"
#include <stdio.h>

int MoveFunction[] = {
0,//0 Fly
0,//1 
0,//2 
0
};

int fly_set = 0;
