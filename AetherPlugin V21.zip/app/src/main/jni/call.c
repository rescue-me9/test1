#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "function/combat.h"
#include "function/move.h"
#include "function/world.h"
#include "function/internet.h"
#include "jotm.h"
#include <jni.h>
#include <string.h>
#include <stdbool.h>


// JNI 方法：设置模块参数
JNIEXPORT jint JNICALL Java_com_Steve_niubi_Call_JNICall_setModuleParameters(JNIEnv *env, jobject obj, jstring moduleName, jint parameter) {
    // 将 Java 的 jstring 转换为 C 风格的字符串
    const char* moduleNameStr = (*env)->GetStringUTFChars(env, moduleName, NULL);
    if (moduleNameStr == NULL) {
        return -1; // 如果转换失败，返回错误码
    }

    // 设置模块参数
    bool result = SetModuleParameter(moduleNameStr, parameter);

    // 释放字符串资源
    (*env)->ReleaseStringUTFChars(env, moduleName, moduleNameStr);

    // 返回结果
    return result ? 0 : -1; // 0 表示成功，-1 表示失败
}

// JNI 方法：设置模块启用状态
JNIEXPORT void JNICALL Java_com_Steve_niubi_Call_JNICall_setModuleEnabled(JNIEnv *env, jobject obj, jstring moduleName, jboolean enabled) {
    // 将 Java 的 jstring 转换为 C 风格的字符串
    const char* moduleNameStr = (*env)->GetStringUTFChars(env, moduleName, NULL);
    if (moduleNameStr == NULL) {
        // 如果转换失败，直接返回
        return;
    }

    // 调用 ToggleModuleEnabled 函数来启用或禁用模块
    ToggleModuleEnabled(moduleNameStr, enabled);

    // 释放字符串资源
    (*env)->ReleaseStringUTFChars(env, moduleName, moduleNameStr);
}

// JNI 方法：获取模块启用状态
JNIEXPORT jboolean JNICALL Java_com_Steve_niubi_Call_JNICall_getModuleEnabled(JNIEnv *env, jobject obj, jstring moduleName) {
    // 将 Java 的 jstring 转换为 C 风格的字符串
    const char* moduleNameStr = (*env)->GetStringUTFChars(env, moduleName, NULL);
    if (moduleNameStr == NULL) {
        return JNI_FALSE; // 如果转换失败，返回 false
    }

    // 获取模块启用状态
    bool ModuleEnabled = IsModuleEnabled(moduleNameStr);

    // 释放字符串资源
    (*env)->ReleaseStringUTFChars(env, moduleName, moduleNameStr);

    // 返回结果
    return ModuleEnabled ? JNI_TRUE : JNI_FALSE;
}

// JNI_OnLoad 函数：在 JNI 库加载时初始化模块
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    if ((*vm)->GetEnv(vm, (void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        return JNI_EVERSION; // 返回版本错误
    }
    // 初始化模块状态
    InitializeModules();
    // 返回支持的 JNI 版本
    return JNI_VERSION_1_6;
}

