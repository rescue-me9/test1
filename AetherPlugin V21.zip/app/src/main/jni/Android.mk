LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_C_INCLUDES +=$(LOCAL_PATH)/
LOCAL_MODULE    := aether
LOCAL_SRC_FILES := call.c
LOCAL_CFLAGS += -std=c99

include $(BUILD_SHARED_LIBRARY)
