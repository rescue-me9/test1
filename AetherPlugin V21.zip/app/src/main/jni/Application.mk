NDK_TOOLCHAIN_VERSION := 4.9
APP_STL := gnustl_static
APP_ABI := arm64-v8a
APP_STL := c++_shared
