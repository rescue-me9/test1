#ifndef HEADER_FILE_NAME_H
#define HEADER_FILE_NAME_H

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/mman.h>
#include <string.h>
#include <errno.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/wait.h>
#include <math.h>


#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define MAX_MODULES 100
#define MAX_NAME_LENGTH 30

typedef char PACKAGENAME;int handle;int getPID(const char *packageName) {int id = -1;DIR *dir;FILE *fp;char filename[64];char cmdline[64];struct dirent *entry;dir = opendir("/proc");while ((entry = readdir(dir)) != NULL) {id = atoi(entry->d_name);if (id != 0) {sprintf(filename, "/proc/%d/cmdline", id);fp = fopen(filename, "r");if (fp) {if (fgets(cmdline, sizeof(cmdline), fp)) {if (strcmp(packageName, cmdline) == 0) {fclose(fp);return id;}}fclose(fp);}}}closedir(dir);return -1;}long getbss(int pid, const char *module_name) {char filename[64];char line[1024];snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);FILE *fp = fopen(filename, "r");if (!fp) return 0;long addr = 0;int is_module = 0;while (fgets(line, sizeof(line), fp)) {if (strstr(line, module_name)) {is_module = 1;}if (is_module && strstr(line, "[anon:.bss]")) {sscanf(line, "%lx", &addr);break;}}fclose(fp);return addr;}
long int lsp64(long int addr) 
{
	long int var = 0;pread64(handle, &var, 8, addr);
	var = var & 0xFFFFFFFFFFFF;return var;
	}
	int WriteAddress_DWORD(long int addr, int value) {pwrite64(handle, &value, 4, addr);return 0;}long int base(){int ipid = getPID("com.netease.mc.m4399");       char lj[64];        snprintf(lj, sizeof(lj), "/proc/%d/mem", ipid);       handle = open(lj, O_RDWR);       char mname[] = "libminecraftpe.so";       long int base = getbss(ipid, mname);       return base;}
//F
float WriteAddress_FLOAT(long int addr, float value) {pwrite64(handle, &value, 4, addr);return 0;}

int getWord(long int addr){short var = 0;    pread64(handle, &var, 2, addr);    return var;}
float gainF(long int addr){float var = 0;pread64(handle, &var, 4, addr);return var;}

long int getXa(int pid, const char *module_name)
{
	FILE *fp;
	long addr = 0;
	char *pch;
	char filename[64];
	char line[1024];
	snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);
	fp = fopen(filename, "r");
	if (fp != NULL)
	{
		while (fgets(line, sizeof(line), fp))
		{
			if (strstr(line, module_name))
			{
				pch = strtok(line, "-");
				addr = strtoul(pch, NULL, 16);
				if (addr == 0x8000)
					addr = 0;
				break;
			}
		}
		fclose(fp);
	}
	return addr;
}

long int baseXa() {
		// 读取游戏进程
	int ipid = getPID("com.netease.mc.4399");
    char lj[64];
	sprintf(lj, "/proc/%d/mem", ipid);
	handle = open(lj, O_RDWR);
	if (handle == 0)
	{
		puts("获取mem失败!");
		exit(1);
	}
		char mname[] = "libminecraftpe.so";	// 基址入口模块
	//Xa用getXa,Cb用getbss,Cd用getCd
	long int baseXa = getXa(ipid, mname);
	return baseXa;
}


typedef struct {
    char name[MAX_NAME_LENGTH];
    int parameter;
    bool enabled;
} Module;

// 模块数组
Module modules[MAX_MODULES] = {
	// Draw
	{"FunctionDraw", 0, false},

	//Combat
	{"Assassination", 0, false},
    {"TPAura", 0, false},
    {"RiptideAura", 0, false},
    {"HitBox", 0, false},

	// Move
    {"NoFallDamage", 0, false},
    {"Fly", 0, false},
    {"AirJump", 0, false},
    {"Wallpiercing", 0, false},
    {"ClickTeleport", 0, false},

	//Player
    {"PlayerTP", 0, false},
    {"VoidRebound", 0, false}
};

// 初始化模块状态为禁用
void InitializeModules() {
    for (int i = 0; i < MAX_MODULES; i++) {
        modules[i].enabled = false;
    }
}

// 查找模块并设置参数
bool SetModuleParameter(const char* moduleName, int parameter) {
    for (int i = 0; i < MAX_MODULES; i++) {
        if (strcmp(modules[i].name, moduleName) == 0) {
            modules[i].parameter = parameter;
            return true; // 参数设置成功
        }
    }
    return false; // 模块未找到
}

// 查找模块并启用或禁用
bool ToggleModuleEnabled(const char* moduleName, bool enabled) {
    for (int i = 0; i < MAX_MODULES; i++) {
        if (strcmp(modules[i].name, moduleName) == 0) {
            modules[i].enabled = enabled;
            return true; // 状态更新成功
        }
    }
    return false; // 模块未找到
}

// 查找模块是否启用
bool IsModuleEnabled(const char* moduleName) {
    for (int i = 0; i < MAX_MODULES; i++) {
        if (strcmp(modules[i].name, moduleName) == 0) {
            return modules[i].enabled; // 返回模块的启用状态
        }
    }
    return false; // 模块未找到，默认返回禁用
}


#endif
