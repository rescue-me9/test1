package com.Steve.niubi;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.Steve.niubi.Call.JNICall;
import com.Steve.niubi.GUI.Combat;
import com.Steve.niubi.GUI.Draw;
import com.Steve.niubi.GUI.Menu;
import com.Steve.niubi.GUI.Move;
import com.Steve.niubi.GUI.Player;
import com.Steve.niubi.GUI.World;
import com.Steve.niubi.GUI.quickly;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.NetworkInterface;
import java.net.URL;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

import static android.graphics.Typeface.BOLD;
	/*
	本模板仅供学习研究
	本模板仅供学习研究
	界面有特多bug点，推荐自己去写界面
	界面有特多bug点，推荐自己去写界面
	界面有特多bug点，推荐自己去写界面	
	 微云端网络验证官网:https://llua.cn
	 1.加密选择RC4-2
	 2.记得把登录，解绑的WY_APPKEY ，WY_APPID,WY_RC4KEY替换掉
	 3.开启数据签名开关
	 4.开启(签名放在Data里)
	 */

public class w165ba317249270f68a8bea38d462f654 {
	SurfaceHolder holder;
    Canvas canvas;
	static String wy_url = "https://wy.llua.cn";//API接口
	static String WY_APPID = "26323"; // 项目id
	static String WY_APPKEY = "bkizHZ5a2050zK02"; //项目key
	static String WY_RC4KEY = "b3acd4eaba3dcbffb61fb443ba144ca3";//RC4密钥
    static LinearLayout linearLayouts;
    static EditText edittext;
    static  AlertDialog.Builder dialogs,dialogs1;
    static AlertDialog alertDialogs,alertDialogs1;
    static AlertDialog alertDialogss;
    static AlertDialog dialog = null;
	public Intent intent;	
	static String 当前版本号="1.0";
    static String 卡密;

	public static void Start(final Activity context) {
	    更新(context);//检测更新与公告
		Login(context);
    }

	
	public static String 获取机器码(Context context) {
	    return  android.provider.Settings.Secure.getString(context.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
    }

	public static boolean isVpnUsed() {//vpn检测
        try {
            List<NetworkInterface> nis = Collections.list(NetworkInterface.getNetworkInterfaces());
            if (nis != null) {
                for (NetworkInterface intf : nis) {
                    if (!intf.isUp() || intf.getInterfaceAddresses().size() == 0) {
                        continue;
                    }
                    if ("tun0".equals(intf.getName()) || "ppp0".equals(intf.getName())) {
                        return true; // The VPN is up
                    }
                }
            }
        } catch (Throwable e) {
			e.printStackTrace();
        }
        return false;
    }
    public static void 更新(final Activity context) {
        new Thread(new Runnable() {
                @Override
                public void run() {
					String sign="/api/?app=" + WY_APPID + "&id=ini"; // 公告
					try {
						String content=RC4Util.decryRC4(UrlPost(wy_url + sign, ""), WY_RC4KEY, "UTF-8");
						JSONObject jsonObject = new JSONObject(content);
						String data=jsonObject.getString("msg");
						JSONObject json = new JSONObject(data);						
						String version = json.getString("version"); //最新版本
						String app_update_show = json.getString("app_update_show"); //更新内容
						final String app_update_url = json.getString("app_update_url"); //最新地址
						String app_update_must = json.getString("app_update_must"); //强制更新	
						if (!version.equals(当前版本号)) {
							Looper.prepare();
							linearLayouts = new LinearLayout(context);
							linearLayouts.setOrientation(1);
							linearLayouts.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
							linearLayouts.setPadding(40, 40, 40, 40);
							dialogs = new AlertDialog.Builder(context, 5);

							final TextView texties = new TextView(context);
							texties.setTextColor(0xFF000000);
							texties.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
							texties.setText("有新版本");
							texties.setTextSize(23.0f);
							texties.setGravity(5);
							final TextView textVies = new TextView(context);
							textVies.setTextColor(0xFF000000);
							textVies.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
							textVies.setTextSize(17.0f);	
							textVies.setText("\n" + app_update_show + "\n");
							Button Butts = new Button(context);
							Butts.setText("立即更新");
							Butts.setTextSize(13.0f);
							Butts.setTextColor(0xFFFFFFFF);
							Butts.setBackgroundColor(0xFF00C0FF);
							Butts.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
							Butts.setOnClickListener(new View.OnClickListener() {
									@Override 
									public void onClick(View view) {
										alertDialogs.dismiss();

										Uri uri = Uri.parse(app_update_url);
										Intent intent = new Intent(Intent.ACTION_VIEW, uri);
										context.startActivity(intent);
									}});
							linearLayouts.addView(texties);
							linearLayouts.addView(textVies);
							linearLayouts.addView(Butts);
							if (app_update_must.equals("y")) {
								dialogs.setCancelable(false);
							}
							dialogs.setView(linearLayouts);
							alertDialogs = dialogs.show();
							Looper.loop();
						}else{
							公告(context);
						}
					} catch (Exception e) {
					}
				}
			}).start(); 
    }

	public static void 公告(final Activity activity) {
        new Thread(new Runnable() {
                @Override
                public void run() {
					String sign="/api/?app=" + WY_APPID + "&id=notice"; // 公告
					try {
						String content=RC4Util.decryRC4(UrlPost(wy_url + sign, ""), WY_RC4KEY, "UTF-8");
						JSONObject jsonObject = new JSONObject(content);
						String data=jsonObject.getString("msg");
						JSONObject json = new JSONObject(data);						
						String appgg=json.optString("app_gg");
						Looper.prepare();
						
		// 创建半透明背景
		final Dialog dialog = new Dialog(activity);
		dialog.setCancelable(false);          // 禁止返回键
		dialog.setCanceledOnTouchOutside(false); // 禁止点击外部关闭
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

		// 根布局：垂直、居中
		LinearLayout root = new LinearLayout(activity);
		root.setOrientation(LinearLayout.VERTICAL);
		root.setGravity(Gravity.CENTER);
		root.setPadding(dp(24,activity), dp(24,activity), dp(24,activity), dp(24,activity));

		// 卡片容器：圆角 + 白色背景
		LinearLayout card = new LinearLayout(activity);
		card.setOrientation(LinearLayout.VERTICAL);
		card.setPadding(dp(20,activity), dp(20,activity), dp(20,activity), dp(20,activity));
		GradientDrawable bg = new GradientDrawable();
		bg.setColor(Color.WHITE);
		bg.setCornerRadius(dp(16,activity));
		bg.setStroke(dp(1,activity), Color.parseColor("#E0E0E0"));
		card.setBackground(bg);

		// 标题
		TextView tvTitle = new TextView(activity);
		tvTitle.setText("公告");
		tvTitle.setTextSize(18);
		tvTitle.setTextColor(Color.parseColor("#212121"));
		tvTitle.setGravity(Gravity.CENTER);
		tvTitle.setPadding(0, dp(8,activity), 0, dp(16,activity));

		// 内容（支持滚动）
		ScrollView scroll = new ScrollView(activity);
		LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(
			ViewGroup.LayoutParams.MATCH_PARENT,
			ViewGroup.LayoutParams.WRAP_CONTENT);
		scroll.setLayoutParams(scrollLp);
		TextView tvContent = new TextView(activity);
		tvContent.setText(appgg);
		tvContent.setTextSize(15);
		tvContent.setTextColor(Color.parseColor("#424242"));
		tvContent.setLineSpacing(dp(4,activity), 1.0f);
		tvContent.setPadding(dp(12,activity), 0, dp(12,activity), 0);
		scroll.addView(tvContent);

		// 确定按钮
		Button btnOk = new Button(activity);
		btnOk.setText("确定");
		btnOk.setAllCaps(false);
		btnOk.setTextSize(16);
		btnOk.setTextColor(Color.WHITE);
		GradientDrawable btnBg = new GradientDrawable();
		btnBg.setColor(Color.parseColor("#FF4081"));
		btnBg.setCornerRadius(dp(50,activity));
		btnOk.setBackground(btnBg);
		LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
			ViewGroup.LayoutParams.MATCH_PARENT,
			dp(48,activity));
		btnLp.setMargins(0, dp(24,activity), 0, 0);
		btnOk.setLayoutParams(btnLp);

		btnOk.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					Toast.makeText(activity, "已阅读公告", Toast.LENGTH_SHORT).show();
					dialog.dismiss();
					
				}});

		// 组装卡片
		card.addView(tvTitle);
		card.addView(scroll);
		card.addView(btnOk);

		// 组装根布局
		root.addView(card);

		dialog.setContentView(root);
		dialog.show();
						Looper.loop();
					} catch (Exception e) {
					}
				}
			}).start(); 
    }

	public static void 登录(final String 卡密, final Activity context) {
		new Thread(new Runnable() {
				@Override
				public void run() {
					String sign = wy_url + "/api/?id=kmlogin"; // 卡密登录
					String content;
					String random;
					String uuid; //系统机器码
					uuid = 获取机器码(context);
					
					Long time = System.currentTimeMillis() / 1000;
					String signs = encodeMD5("kami=" + 卡密 + "&markcode=" + uuid + "&t=" + time + "&" + WY_APPKEY);
					String body="&app=" + WY_APPID + "&kami=" + 卡密 + "&markcode=" + uuid + "&t=" + time + "&sign=" + signs;		
					String 提交内容=sign + body;
					
						random = UUID.randomUUID().toString().replace("-", "") + WY_APPKEY + uuid;
                        try {
							String data = "data=" + RC4Util.encryRC4String(body, WY_RC4KEY, "UTF-8");
							content = RC4Util.decryRC4(UrlPost(提交内容 + "&app=" + WY_APPID, data + "&value=" + random), WY_RC4KEY, "UTF-8");
							JSONObject jsonObject = new JSONObject(content);
							String code=jsonObject.getString("e8a67656573ee2a9131fa64524a0c3bb5");//是否登录成功
							String Message=jsonObject.getString("m0a6037b0b916f99bf0e9c90d0134eed8");
							String check=jsonObject.optString("p87077e655e8102e0232b0d37efbd6fd7");//校验密钥
							Long timee=jsonObject.optLong("b86b964fb55c4ec1897807c7772662e20");//服务器时间戳
							
							if (code.equals("10607")) {//登录成功
							    JSONObject json = new JSONObject(Message);
							    Long kamid=json.optLong("q1a654b2a71d3eb2c5a872850aaae5c60");
							    if (!check.equals(encodeMD5(""+timee.toString()+""+WY_APPKEY+""+random+""))) {
								    Looper.prepare();							
								    Toast.makeText(context, "非法操作", Toast.LENGTH_LONG).show();
								    Looper.loop();
							    }else if (timee - time > 30) {
							        Looper.prepare();							
							        Toast.makeText(context, "数据过期", Toast.LENGTH_LONG).show();
							        Looper.loop();
							    } else if (timee - time < -30) {
							        Looper.prepare();							
							        Toast.makeText(context, "数据过期", Toast.LENGTH_LONG).show();
							        Looper.loop();
							    }else{
									Long vip=json.optLong("r0214016caed7c56b4b7fa3876469a7e7");
									GregorianCalendar gc=new GregorianCalendar();
									gc.setTimeInMillis(vip * 1000);
									SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
									Looper.prepare();
									Toast.makeText(context, "登录成功\n到期时间:" + df.format(gc.getTime()), Toast.LENGTH_LONG).show();
									
									new Menu().Start(context);
									new Combat().Start(context);
									new Move().Start(context);
									new Player().Start(context);
									new World().Start(context);
									new Draw().Start(context);
									new quickly().Start(context);

									new Handler(Looper.getMainLooper()).postDelayed(new Runnable(){

											@Override
											public void run() {
												new Menu().a(context);
												dialog.dismiss();
											}
										}, 1000);
									alertDialogss.dismiss();
									Looper.loop();
								}
							} else {
								Looper.prepare();
								Toast.makeText(context, Message, Toast.LENGTH_LONG).show();
								Looper.loop();
							}
						} catch (JSONException e) {
							Looper.prepare();
							Toast.makeText(context, "错误"+e, Toast.LENGTH_LONG).show();
							Looper.loop();
						} catch (Exception e) {
                        }
                    }

                

            }).start(); 
    }

	public static void 解绑(final String 卡密, final Context context) {

		new Thread(new Runnable() {         
				@Override
				public void run() {
					String sign = wy_url + "/api/?id=kmdismiss"; // 卡密解绑
					String content;
					String random;
					String uuid;
					uuid = 获取机器码(context);
					
					random = UUID.randomUUID().toString().replace("-", "") + WY_APPKEY + uuid;			
					Long time = System.currentTimeMillis() / 1000;
					String signs = encodeMD5("kami=" + 卡密 + "&markcode=" + uuid + "&t=" + time + "&" + WY_APPKEY);
					String body="&app=" + WY_APPID + "&kami=" + 卡密 + "&markcode=" + uuid + "&t=" + time + "&sign=" + signs;		
					String 提交内容=sign + body;
					
                        try {
							String data = "data=" + RC4Util.encryRC4String(body, WY_RC4KEY, "UTF-8");
							content = RC4Util.decryRC4(UrlPost(提交内容 + "&app=" + WY_APPID, data + "&value=" + random), WY_RC4KEY, "UTF-8");
							JSONObject jsonObject = new JSONObject(content);
							String code=jsonObject.getString("code");//是否解绑成功
							String Message=jsonObject.getString("msg");
							if (code.equals("200")) {//解绑成功
								JSONObject json = new JSONObject(Message);						
								String num=json.getString("num");
								Looper.prepare();
								Toast.makeText(context, "解绑成功\n当前卡密解绑次数剩余 " + num + " 次", Toast.LENGTH_LONG).show();
								Looper.loop();
							} else {
								Looper.prepare();
								Toast.makeText(context, Message, Toast.LENGTH_LONG).show();
								Looper.loop();
							}
						} catch (JSONException e) {
							Looper.prepare();

							Toast.makeText(context, "服务器连接失败", Toast.LENGTH_LONG).show();
							Looper.loop();
						} catch (Exception e) {
						}
					}

				
			}).start(); 
    }

	static void Login(final Activity context) {
        final Context ctx = context;
		final Activity activity = context;

		// 2. 根布局（垂直 LinearLayout）
		LinearLayout root = new LinearLayout(ctx);
		root.setOrientation(LinearLayout.VERTICAL);
		root.setPadding(dp(24,activity), dp(24,activity), dp(24,activity), dp(24,activity));
		root.setBackground(roundRect(0xFFECEFF1,activity));   // 浅灰圆角背景

		// 3. 标题
		TextView tvTitle = new TextView(ctx);
		tvTitle.setText("SteveBox");
		tvTitle.setTextSize(20);
		tvTitle.setTextColor(0xFF000000);
		tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
		tvTitle.setGravity(Gravity.CENTER);
		root.addView(tvTitle);

		// 4. 副标题
		TextView tvSub = new TextView(ctx);
		tvSub.setText("");
		tvSub.setTextSize(14);
		tvSub.setTextColor(0xFF666666);
		tvSub.setGravity(Gravity.CENTER);
		tvSub.setPadding(0, dp(4,activity), 0, dp(16,activity));
		root.addView(tvSub);

		// 5. 提示文字
		TextView tvTip = new TextView(ctx);
		tvTip.setText("单击登录" + "\n长按解绑");
		tvTip.setTextSize(12);
		tvTip.setTextColor(0xFF666666);
		tvTip.setGravity(Gravity.CENTER);
		root.addView(tvTip);

		// 6. 输入框
		final EditText etCard = new EditText(ctx);
		etCard.setHint("请输入卡密登录");
		etCard.setTextSize(14);
		etCard.setPadding(dp(12,activity), dp(12,activity), dp(12,activity), dp(12,activity));
		etCard.setBackground(roundRect(0xFFFFFFFF,activity));
		root.addView(etCard);

		// 8. 水平按钮容器
		LinearLayout btnLine = new LinearLayout(ctx);
		btnLine.setOrientation(LinearLayout.HORIZONTAL);
		btnLine.setGravity(Gravity.CENTER);
		btnLine.setPadding(0, dp(8,activity), 0, 0);

		// 9. 按钮：卡密登录
		Button btnLogin = new Button(ctx);
		btnLogin.setText("登录");
		styleButton(btnLogin, 0xFF6200EE,activity);
		btnLine.addView(btnLogin);

		// 10. 按钮：进入群聊
		Button btnBuy = new Button(ctx);
		btnBuy.setText("进入官方群");
		styleButton(btnBuy, 0xFF00C853,activity);
		btnLine.addView(btnBuy);
		
		// 11. 按钮 : 购买卡密
		Button btnBuy1 = new Button(ctx);
		btnBuy1.setText("购买卡密");
		styleButton(btnBuy1, 0xFF00C853,activity);
		btnLine.addView(btnBuy1);

		root.addView(btnLine);

		// 11. AlertDialog
		dialog = new AlertDialog.Builder(ctx)
			.setView(root)
			.setCancelable(false)
			.show();



		// 12. 事件
		btnLogin.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View view) {
					
					if (isVpnUsed()) {
						System.exit(0);   
					}
                    卡密 = etCard.getText().toString();
                    if (卡密.length() == 0) {
                        Toast.makeText(context, "请输入正确卡密格式" , Toast.LENGTH_SHORT).show();
                    } else {
                        登录(卡密, context);
                    }

				}
			});
		btnLogin.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View view) {
					卡密 = etCard.getText().toString();
                    if (卡密.length() == 0) {
                        Toast.makeText(context, "请输入正确卡密格式" , Toast.LENGTH_SHORT).show();
                    } else {
                        解绑(卡密, context);
                    }
					return false;
				}
			});
		btnBuy.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View view) {
					// 打开购买链接或群聊
					String url = "https://qun.qq.com/universal-share/share?ac=1&authKey=GTe7BrOerRCCipq%2BLrEIe0L%2F0JjjPRlZpLX1jR70CsBp6F4AMUWHvvr49L0sHkbZ&busi_data=eyJncm91cENvZGUiOiI2MzkxMDkzODQiLCJ0b2tlbiI6IjJTL3NPNWY0OUdHbGMwdGMwRFJTbjhXMzlrblN3TEltNTFWOGlaaEc3ZXZMSm5vMWYyZlpJK0l0SVNBaExRVjMiLCJ1aW4iOiIzNjIwNTMxOTA4In0%3D&data=AoUYgYn198t_7y7x_Y00XK6zkqsPdfonQnIWA0DeTh1sVdINYeWi-JzQpZltVP4joHFyBH518qhRI0o0W5IH_g&svctype=4&tempid=h5_group_info";				
					Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
					activity.startActivity(i);
				}});
		btnBuy1.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View view) {
					// 打开购买链接或群聊
					String url = "https://916ifk.longpai.hk/links/BE3EE52E";
					Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
					activity.startActivity(i);
				}});
	}

    public static void 创建文件夹(String path) {
        //新建一个File，传入文件夹目录
        File file = new File(path);
        //判断文件夹是否存在，如果不存在就创建，否则不创建
        if (!file.exists()) {
            //通过file的mkdirs()方法创建目录中包含却不存在的文件夹
            file.mkdirs();
        }

    }

	public static void 写入(String Files, String content) {
		try {
			FileWriter utf = new FileWriter(Files);
			utf.write(content);
			utf.close();
		} catch (IOException e) {}
	}

	public static String UrlPost(String ur, String byteString) {
        String str="";		
        try {
            URL url=new URL(ur);
            HttpURLConnection HttpURLConnection=(HttpURLConnection) url.openConnection();
            HttpURLConnection.setReadTimeout(9000);
            HttpURLConnection.setRequestMethod("POST");
            OutputStream outputStream = HttpURLConnection.getOutputStream();
            outputStream.write(byteString.getBytes());
            BufferedReader BufferedReader=new BufferedReader(new InputStreamReader(HttpURLConnection.getInputStream()));
            String String="";
            StringBuffer StringBuffer=new StringBuffer();
            while ((String = BufferedReader.readLine()) != null) {
                StringBuffer.append(String);
            }
            str = StringBuffer.toString();
        } catch (IOException e) {}
        return str;
    }
	public static String 读取文件(String path) {
        String str = "";
        try {
            File urlFile = new File(path);
            InputStreamReader isr = new InputStreamReader(new FileInputStream(urlFile), "UTF-8");
            BufferedReader br = new BufferedReader(isr);

            String mimeTypeLine = null;
            while ((mimeTypeLine = br.readLine()) != null) {
                str = str + mimeTypeLine;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return str;
    }
	public static String encodeMD5(String str) {
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(str.getBytes("UTF-8"));
            byte messageDigest[] = md5.digest();
            StringBuilder hexString = new StringBuilder();
            for (byte b : messageDigest) {
                hexString.append(String.format("%02X", b));
            }
            return hexString.toString().toLowerCase();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
	
	
	private static int dp(int value, Activity activity) {
		return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            activity.getResources().getDisplayMetrics());
	}

// 生成圆角 Shape
	private static GradientDrawable roundRect(int solidColor, Activity activity) {
		GradientDrawable d = new GradientDrawable();
		d.setColor(solidColor);
		d.setCornerRadius(dp(8,activity));
		return d;
	}

// 统一按钮样式
	private static void styleButton(Button btn, int color, Activity activity) {
		btn.setTextColor(Color.WHITE);
		btn.setTextSize(14);
		btn.setAllCaps(false);
		btn.setBackground(roundRect(color,activity));
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            dp(100,activity), dp(40,activity));
		lp.leftMargin = dp(8,activity);
		lp.rightMargin = dp(8,activity);
		btn.setLayoutParams(lp);
	}
}

	

