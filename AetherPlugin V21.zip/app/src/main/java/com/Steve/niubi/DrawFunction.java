package com.Steve.niubi;

import android.app.Activity;
import android.content.Context;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout.LayoutParams;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import com.Steve.niubi.Call.JNICall;
import com.Steve.niubi.GUI.layout.layout;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class DrawFunction {
	/*
	* by.jotm
	* 没写停止循环
	*/

	/*颜色值RGB*/
    public static int MSR=255;
    public static int MSG=0;
    public static int MSB=0;

	public static Thread th;
	private PopupWindow popupWindon;
    public void Start(final Activity Activity) {
		Context context = Activity.getApplicationContext();
		int screenWidth = context.getResources().getDisplayMetrics().widthPixels;

		int size = (int) (screenWidth * 0.008);
		
		LinearLayout layout = new LinearLayout(Activity);	
		final TextView drawText = new TextView(Activity);
		drawText.setGravity(Gravity.END);
		drawText.setTextSize(size);
		drawText.setText(Draw(Activity));
        
        
		layout.addView(drawText);
		final View rightBorder = new View(Activity);
		rightBorder.setBackgroundColor(0xFFFFFFFF); // 设置边框颜色为白色
		LinearLayout.LayoutParams borderParams = new LinearLayout.LayoutParams(
			10, // 宽度为1px，表示边框的厚度
			LinearLayout.LayoutParams.MATCH_PARENT // 高度匹配父布局
		);
		rightBorder.setX(5);
		layout.addView(rightBorder, borderParams); // 将边框添加到布局中
		
		
		popupWindon = new PopupWindow(layout,LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT,false);
        popupWindon.setOutsideTouchable(false);
        popupWindon.setTouchable(false);
        popupWindon.setTouchInterceptor(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    // 在这里处理触摸事件，决定是否透传
                    return false; // 返回false让事件继续传递
                }
            });
        
		popupWindon.showAtLocation(Activity.getWindow().getDecorView(),Gravity.END | Gravity.TOP,40,0);
		
		final Thread th1= new Thread(new Runnable() {
                @Override
                public void run() {
                    while (true) {
                        Activity.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
									JNICall JNICall = new JNICall();
									if(JNICall.getModuleEnabled("FunctionDraw")) drawText.setText(Draw(Activity));
									if (!JNICall.getModuleEnabled("FunctionDraw")) drawText.setText(null);
                                    
                                }});
                        try {
                            Thread.sleep(250);
                        } catch (InterruptedException e) {
                        }
                    }
                }});
        th1.start();
		th= new Thread(new Runnable() {
                @Override
                public void run() {
                    /*颜色变化算法*/
                    while (true) {
                        if (MSR >= 0 && MSB == 0) {
                            MSR = MSR - 5;
                            MSG = MSG + 5; 
                        }
                        if (MSG >= 0 && MSR == 0) {
                            MSG = MSG - 5;
                            MSB = MSB + 5;
                        }
                        if (MSB >= 0 && MSG == 0) {
                            MSR = MSR + 5;
                            MSB = MSB - 5;
                        }
                        String c=rgb2Hex(MSR, MSG, MSB);
                        try {
                            drawText.setTextColor(hexColor(c));
                            drawText.setShadowLayer(10, 10, 0, hexColor(c));
                            JNICall JNICall = new JNICall();
							if(JNICall.getModuleEnabled("FunctionDraw")) {
							rightBorder.setBackgroundColor(hexColor(c));
                            } else {
                                rightBorder.setBackgroundColor(0x000000);
                            }
                        } catch (Throwable e) {
                            System.out.println(e);
                        }
                        try {
                            Thread.sleep(50);
                        } catch (InterruptedException e) {

                        }
                    }
                }});
        th.start();
	}
    
	

	
	
	public String Draw(Activity activity) {
		List<String> selectedStrings = new ArrayList<>();

		// 添加Combat_Name中的字符串
		for (String str : layout.Combat_Name) {
        if (new JNICall().getModuleEnabled(str)) {
		selectedStrings.add(str);
			}
				}

		// 添加Move_Name中的字符串
		for (String str : layout.Move_Name) {
        if (new JNICall().getModuleEnabled(str)) {
		selectedStrings.add(str);
			}
				}

		// 添加World_Name中的字符串
		for (String str : layout.World_Name) {
        if (new JNICall().getModuleEnabled(str)) {
		selectedStrings.add(str);
			}
				}

		// 添加Player_Name中的字符串
		for (String str : layout.Player_Name) {
        if (new JNICall().getModuleEnabled(str)) {
		selectedStrings.add(str);
			}
				}

		// 从大到小排序
		Collections.sort(selectedStrings, new Comparator<String>() {
				@Override
				public int compare(String a, String b) {
					return b.length() - a.length();
				}
			});
		

		// 拼接字符串
		StringBuilder result = new StringBuilder();
			for (int i = 0; i < selectedStrings.size(); i++) {
			result.append(selectedStrings.get(i));
				if (i < selectedStrings.size() - 1) {
            result.append("\n");
        }
		}

		String s = "";
		if (result.toString().equals("")) {
			s = "";
		} else {
			s = "\n";
		}
		return "AetherPlugin [2.0]" + s + result.toString();
	}
	
	
	
	
	
	
	/*RGB转16进制*/
    public static String rgb2Hex(int r, int g, int b) {
        return String.format("#%02X%02X%02X", r, g, b);
    }
	public static int hexColor(String c) {
		return android.graphics.Color.parseColor(c);
	};
		public static void insertInOrder(List<String> list, String str) {
			int index = 0;
			while (index < list.size() && list.get(index).compareTo(str) > 0) {
				index++;
			}
			list.add(index, str);
		}
}
