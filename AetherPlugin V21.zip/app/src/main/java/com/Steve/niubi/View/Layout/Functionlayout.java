package com.Steve.niubi.View.Layout;
import android.app.Activity;
import android.widget.LinearLayout;
import android.widget.SeekBar;

public class Functionlayout {
    public static boolean HitBox = false;
    public static LinearLayout HitBox_Layout(Activity activity) {
		LinearLayout layout = new LinearLayout(activity);
		layout.setBackgroundColor(0x1A000000);
		SeekBar seekBar = new SeekBar(activity);
		
		layout.addView(seekBar);
		return layout;
	}
    
}
