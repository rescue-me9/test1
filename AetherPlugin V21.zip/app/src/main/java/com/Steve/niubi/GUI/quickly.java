package com.Steve.niubi.GUI;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import com.Steve.niubi.GUI.layout.layout;
import com.Steve.niubi.Other;
import com.Steve.niubi.GUI.quicklyView.ab;

public class quickly {

	private static PopupWindow popupWindow;
	private static boolean open = true;
	private static boolean canmovew = false;
    public static void Start(final Activity activity) {
		Context context = activity.getApplicationContext();
		int screenWidth = context.getResources().getDisplayMetrics().widthPixels;
		int width = (int) (screenWidth * 0.17); // 设置宽度为屏幕宽度的15%

		final LinearLayout linearLayout = new LinearLayout(activity);
		linearLayout.setOrientation(LinearLayout.VERTICAL);
		linearLayout.setPadding(16, 16, 16, 16); // 设置内边距为16

		// 设置LinearLayout的宽度为width，高度为自动适应子视图
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(width, LinearLayout.LayoutParams.WRAP_CONTENT);
		linearLayout.setLayoutParams(layoutParams);

		// 创建渐变背景
		GradientDrawable backgroundGradient = new GradientDrawable(
			GradientDrawable.Orientation.TOP_BOTTOM,
			new int[]{0xFFcc99ff, Color.parseColor("#87CEFA")} // 渐变色值：浅紫到深紫
		);
		backgroundGradient.setCornerRadius(8); // 设置圆角为8
		backgroundGradient.setStroke(10, 0x00000000); // 设置边框宽度为10，颜色为黑色
		linearLayout.setBackground(backgroundGradient);

		// 添加标题MCEM
		TextView title = new TextView(activity);
		title.setText("快捷键");
		title.setTypeface(null, Typeface.BOLD);
		title.setTextColor(Color.WHITE);
		title.setGravity(Gravity.CENTER);
		title.setPadding(16, 16, 16, 16); // 标题的内边距保持为16
		linearLayout.addView(title);
		
		

		// 添加菜单项


		GradientDrawable backgroundGradient1 = new GradientDrawable();
		backgroundGradient1.setCornerRadius(8); // 设置圆角为8
		ScrollView b = new ScrollView(activity);
		
		final LinearLayout a = new LinearLayout(activity);
		a.setBackgroundDrawable(backgroundGradient1);
		a.setClipToOutline(true);
		
		view(layout.Combat_Name, layout.Combat_Color, layout.Combat_function, activity, a);
		view(layout.Move_Name, layout.Move_Color, layout.Move_function, activity, a);
		view(layout.Player_Name, layout.Player_Color, layout.Player_function, activity, a);
		view(layout.World_Name, layout.World_Color, layout.World_function, activity, a);
		view(layout.Draw_Name, layout.Draw_Color, layout.Draw_function, activity, a);
		linearLayout.addView(b);
		b.addView(a);

		title.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					
					open = !open;
				}
			});

		title.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View view) {
					popupWindow.dismiss();
					return false;
				}
			});
		title.setOnTouchListener(new View.OnTouchListener(){
				float lastX = Other.Extend_lastX;
				float lastY = Other.Extend_lastY;
				float nowX = Other.Extend_nowX;
				float nowY = Other.Extend_nowY;
				float tranX = Other.Extend_tranX;
				float tranY = Other.Extend_tranY;
				//private int X1=opMPX;
				//private int Y1=opMPY;
				@Override
				public boolean onTouch(View view, MotionEvent event) {
					int action = event.getAction();
					if (action == MotionEvent.ACTION_DOWN) {
						//点击
						lastX = (int)event.getRawX();
						lastY = (int)event.getRawY();
					} else 
					if (action == MotionEvent.ACTION_MOVE && canmovew) {
						//移动
						nowX = (int)event.getRawX();
						nowY = (int)event.getRawY();
						// 计算XY坐标偏移量
						tranX = (int)(nowX) - (int)(lastX);//*-1/10;
						tranY = (int)(nowY) - (int)(lastY);//*-1/10;
						Other.Extend_opMPX += tranX;
						Other.Extend_opMPY += tranY;
						popupWindow.update(Other.Extend_opMPX, Other.Extend_opMPY, -1, -1);
						lastX = (int)nowX;
						lastY = (int)nowY;
						//opMPX=X1;
						//opMPY=X1;
					}
					//停止触摸
					if (action == MotionEvent.ACTION_UP) {
						canmovew = false;
					}
					return false;
				}
			});
		
		if (Other.Combat_width.equals("WRAP")) {
            popupWindow = new PopupWindow(linearLayout,LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT);
        } else {
            popupWindow = new PopupWindow(linearLayout,Integer.parseInt(Other.quickly_width),LinearLayout.LayoutParams.WRAP_CONTENT);
        }
	}
	public static void a(Activity activity) {
		if (popupWindow != null)
			popupWindow.showAtLocation(activity.getWindow().getDecorView(),Gravity.CENTER,0,0);
		popupWindow.update(Other.Extend_opMPX, Other.Extend_opMPY, -1, -1);
	}

	public static void b(Activity activity) {
		if (popupWindow != null)
			popupWindow.dismiss();
	}


	private static void view(final String[] menuItems, int[] backgroundColors, int[] function, final Activity activity, LinearLayout layout1) {
		
		Context context = activity.getApplicationContext();
		int screenWidth = context.getResources().getDisplayMetrics().widthPixels;
		final int width = (int) (screenWidth * 0.1); // 设置宽度为屏幕宽度的15%
		// 创建一个新的LinearLayout（每次调用都创建一个新的布局）
		LinearLayout layout = new LinearLayout(activity);
		layout.setOrientation(LinearLayout.VERTICAL);

		for (int i = 0; i < menuItems.length; i++) {
			final int a = i;
			LinearLayout menuItemContainer = new LinearLayout(activity);
			menuItemContainer.setOrientation(LinearLayout.HORIZONTAL);
			menuItemContainer.setLayoutParams(new LinearLayout.LayoutParams(
												  LinearLayout.LayoutParams.MATCH_PARENT, // 宽度填满父布局
												  LinearLayout.LayoutParams.WRAP_CONTENT)); // 高度包裹内容
			menuItemContainer.setGravity(Gravity.CENTER_VERTICAL); // 垂直居中对齐
			menuItemContainer.setBackground(new ColorDrawable(backgroundColors[i]));

			// 菜单文本
			TextView menuItemText = new TextView(activity);
			menuItemText.setText(menuItems[i]);
			menuItemText.setTextColor(Color.WHITE);
			menuItemText.setGravity(Gravity.START | Gravity.CENTER_VERTICAL); // 左对齐并垂直居中
			menuItemText.setPadding(16, 16, 16, 16); // 设置内边距
			// 添加到容器
			menuItemContainer.addView(menuItemText);
			
			menuItemText.setOnLongClickListener(new View.OnLongClickListener() {
					@Override
					public boolean onLongClick(View view) {
						ab.pw(activity,menuItems[a]);
                        return false;
					}
				});

			// 添加到LinearLayout
			layout.addView(menuItemContainer);
		}
		layout1.addView(layout);
	}
	
}
