package com.Steve.niubi.GUI;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import com.Steve.niubi.GUI.layout.layout;
import com.Steve.niubi.Other;
import com.Steve.niubi.View.view;

public class Combat {

	private static PopupWindow popupWindow;
	private static boolean open = true;
	private static boolean canmovew = false;
    public static void Start(final Activity activity) {
		Context context = activity.getApplicationContext();
		int screenWidth = context.getResources().getDisplayMetrics().widthPixels;
		int width = (int) (screenWidth * 0.17); // 设置宽度为屏幕宽度的15%

		final LinearLayout linearLayout = new LinearLayout(activity);
		linearLayout.setOrientation(LinearLayout.VERTICAL);
		linearLayout.setPadding(16, 16, 16, 16); // 设置内边距为16

		// 设置LinearLayout的宽度为width，高度为自动适应子视图
		

        LinearLayout.LayoutParams layoutParams;
            layoutParams = new LinearLayout.LayoutParams(
                width, // 宽度为 WRAP_CONTENT
                LinearLayout.LayoutParams.WRAP_CONTENT  // 高度为 WRAP_CONTENT
            );

        // 应用布局参数
        linearLayout.setLayoutParams(layoutParams);
		
		GradientDrawable backgroundGradient = new GradientDrawable(
			GradientDrawable.Orientation.TOP_BOTTOM,
			new int[]{0xFFcc99ff, 0xFF87CEFA});
		backgroundGradient.setCornerRadius(8); // 设置圆角为8
		backgroundGradient.setStroke(10, 0x00000000); // 设置边框宽度为10，颜色为黑色
		linearLayout.setBackground(backgroundGradient);
		
		
		

		// 添加标题MCEM
		TextView title = new TextView(activity);
		title.setText("Combat");
		title.setTypeface(null, Typeface.BOLD);
		title.setTextColor(Color.WHITE);
		title.setGravity(Gravity.CENTER);
		title.setPadding(16, 16, 16, 16); // 标题的内边距保持为16
		linearLayout.addView(title);
		// 添加菜单项


		GradientDrawable backgroundGradient1 = new GradientDrawable();
		backgroundGradient1.setCornerRadius(8); // 设置圆角为8
		final LinearLayout a = view.createMenuView(layout.Combat_Name, layout.Combat_Color, layout.Combat_function, activity);
		a.setBackgroundDrawable(backgroundGradient1);
		a.setClipToOutline(true);
		linearLayout.addView(a);

		title.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					if (open) {
						collapseLinearLayout(a, 500);
					} else {
						expandLinearLayout(a, 500);
					}
					open = !open;
				}
			});

		title.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View view) {
					canmovew = true;
					return false;
				}
			});
		title.setOnTouchListener(new View.OnTouchListener(){
				float lastX = Other.Combat_lastX;
				float lastY = Other.Combat_lastY;
				float nowX = Other.Combat_nowX;
				float nowY = Other.Combat_nowY;
				float tranX = Other.Combat_tranX;
				float tranY = Other.Combat_tranY;
                //private int X1=opMPX;
                //private int Y1=opMPY;
                @Override
                public boolean onTouch(View view, MotionEvent event) {
                    int action = event.getAction();
					if (action == MotionEvent.ACTION_DOWN) {
                        //点击
                        lastX = (int)event.getRawX();
                        lastY = (int)event.getRawY();
                    } else 
                    if (action == MotionEvent.ACTION_MOVE && canmovew) {
                        //移动
                        nowX = (int)event.getRawX();
                        nowY = (int)event.getRawY();
                        // 计算XY坐标偏移量
                        tranX = (int)(nowX) - (int)(lastX);//*-1/10;
                        tranY = (int)(nowY) - (int)(lastY);//*-1/10;
                        Other.Combat_opMPX += tranX;
                        Other.Combat_opMPY += tranY;
                        popupWindow.update(Other.Combat_opMPX, Other.Combat_opMPY, -1, -1);
                        lastX = (int)nowX;
                        lastY = (int)nowY;
                        //opMPX=X1;
                        //opMPY=X1;
                    }
					//停止触摸
					if (action == MotionEvent.ACTION_UP) {
						canmovew = false;
					}
                    return false;
                }
			});
		if (Other.Combat_width.equals("WRAP")) {
            popupWindow = new PopupWindow(linearLayout, width, LayoutParams.WRAP_CONTENT);
        } else {
            popupWindow = new PopupWindow(linearLayout, Integer.parseInt(Other.Combat_width), LinearLayout.LayoutParams.WRAP_CONTENT);
        }
	}
	public static void a(Activity activity) {
		if (popupWindow != null)
			popupWindow.showAtLocation(activity.getWindow().getDecorView(),Gravity.START | Gravity.TOP,0,0);
			popupWindow.update(Other.Combat_opMPX, Other.Combat_opMPY, -1, -1);
	}
	
	public static void b(Activity activity) {
		if (popupWindow != null)
			popupWindow.dismiss();
	}


	private static ValueAnimator currentAnimator;
	private static int currentHeight = 0;

	// 展开动画
	public static void expandLinearLayout(final LinearLayout linearLayout, int duration) {
		// 如果当前有动画在运行，取消它
		if (currentAnimator != null) {
			currentAnimator.cancel();
		}

		// 设置为可见
		linearLayout.setVisibility(View.VISIBLE);

		// 测量目标高度
		linearLayout.measure(View.MeasureSpec.makeMeasureSpec(linearLayout.getWidth(), View.MeasureSpec.EXACTLY),
							 View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
		final int targetHeight = linearLayout.getMeasuredHeight();

		// 设置初始高度为当前高度
		final LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) linearLayout.getLayoutParams();
		layoutParams.height = currentHeight;
		linearLayout.setLayoutParams(layoutParams);

		// 创建动画
		currentAnimator = ValueAnimator.ofInt(currentHeight, targetHeight);
		currentAnimator.setDuration(duration);
		currentAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
				@Override
				public void onAnimationUpdate(ValueAnimator valueAnimator) {
					int newHeight = (int) valueAnimator.getAnimatedValue();
					currentHeight = newHeight;
					layoutParams.height = newHeight;
					linearLayout.setLayoutParams(layoutParams);
				}
			});
		currentAnimator.start();
	}

	// 收缩动画
	public static void collapseLinearLayout(final LinearLayout linearLayout, int duration) {
		// 如果当前有动画在运行，取消它
		if (currentAnimator != null) {
			currentAnimator.cancel();
		}

		// 获取当前高度
		final int initialHeight = currentHeight != 0 ? currentHeight : linearLayout.getHeight();

		// 创建动画
		currentAnimator = ValueAnimator.ofInt(initialHeight, 0);
		currentAnimator.setDuration(duration);
		currentAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
				@Override
				public void onAnimationUpdate(ValueAnimator valueAnimator) {
					int newHeight = (int) valueAnimator.getAnimatedValue();
					currentHeight = newHeight;
					LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) linearLayout.getLayoutParams();
					layoutParams.height = newHeight;
					linearLayout.setLayoutParams(layoutParams);

					if (newHeight == 0) {
						linearLayout.setVisibility(View.GONE);
					}
				}
			});
		currentAnimator.start();
	}
}
