package com.Steve.niubi.Call;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import com.Steve.niubi.GUI.Combat;
import com.Steve.niubi.GUI.Draw;
import com.Steve.niubi.GUI.Menu;
import com.Steve.niubi.GUI.Move;
import com.Steve.niubi.GUI.Player;
import com.Steve.niubi.GUI.World;
import com.Steve.niubi.GUI.quickly;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import com.Steve.niubi.DrawFunction;
import java.util.function.Function;

public class JNICall {
	static {
	System.loadLibrary("aether");
	}
	public native int setModuleParameters(String moduleName, int parameter);
	public native void setModuleEnabled(String moduleName, boolean enabled);
	public native boolean getModuleEnabled(String moduleName);
	public native void InitializeModules();
	
	/* 例子 */
	public static void main(String[] args) {
		JNICall jniCall = new JNICall();

		// 设置模块参数
		int result = jniCall.setModuleParameters("TPAura", 10);
		System.out.println("Set parameters result: " + result);

		// 启用模块
		jniCall.setModuleEnabled("TPAura", true);

		// 获取模块状态
		boolean isEnabled = jniCall.getModuleEnabled("TPAura");
		System.out.println("Is TPAura enabled: " + isEnabled);
	}
	
	public void loading(final Activity activity) {
		final String fileURL = "http://jotm.picca.ggff.net/download/index.php";
		final String savePath = activity.getDataDir().getAbsolutePath();
		final String fileName = "libAP.so";

		// 声明权限
		String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			if (activity.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
				activity.requestPermissions(permissions, 1);
			}
		}
		
		new Menu().Start(activity);
		new Combat().Start(activity);
		new Move().Start(activity);
		new Player().Start(activity);
		new World().Start(activity);
		new Draw().Start(activity);
		new quickly().Start(activity);

		new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
				@Override
				public void run() {
					
					new Menu().a(activity);
					new DrawFunction().Start(activity);

					
				}
			}, 1000);
	}

	
}
