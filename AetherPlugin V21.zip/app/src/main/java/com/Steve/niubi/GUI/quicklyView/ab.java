package com.Steve.niubi.GUI.quicklyView;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;
import com.Steve.niubi.Call.JNICall;
import java.util.HashSet;
import java.util.Set;
import static android.content.res.Resources.getSystem;

public class ab {
    // 用于存储已经存在的string值
    private static Set<String> existingStrings = new HashSet<>();

    private float lastX;
    private float lastY;
    private float nowX;
    private float nowY;
    private float tranX;
    private float tranY;
    private int opMPX;
    private int opMPY;
    private boolean canMove;

    private static final int colorOn = 0xDD4CAF50;
    private static final int colorOff = 0xDD333333;

    public ab() {
        canMove = false;
    }

    public void onLongClick() {
        canMove = true;
    }

    public boolean onTouch(View view, MotionEvent event, PopupWindow popupWindow) {
        int action = event.getAction();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                lastX = event.getRawX();
                lastY = event.getRawY();
                break;
            case MotionEvent.ACTION_MOVE:
                if (canMove) {
                    nowX = event.getRawX();
                    nowY = event.getRawY();
                    tranX = nowX - lastX;
                    tranY = nowY - lastY;
                    opMPX += (int) tranX;
                    opMPY += (int) tranY;
                    popupWindow.update(opMPX, opMPY, -1, -1);
                    lastX = nowX;
                    lastY = nowY;
                }
                break;
            case MotionEvent.ACTION_UP:
                canMove = false;
                break;
        }
        return false;
    }

    public static void pw(Activity activity, final String string) {
        // 检查string是否已经存在于集合中
        if (!existingStrings.contains(string)) {
            // 如果不存在，添加到集合中
            existingStrings.add(string);
        } else {
            // 如果已经存在，可以执行其他逻辑（如返回或提示）
            Toast.makeText(activity.getApplication(), "当前快捷键已存在", Toast.LENGTH_SHORT).show();
            return;
        }

        final LinearLayout linearLayout = new LinearLayout(activity);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setPadding(16, 16, 16, 16);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        linearLayout.setLayoutParams(layoutParams);

		final GradientDrawable background = new GradientDrawable();
        background.setShape(GradientDrawable.RECTANGLE);
        background.setCornerRadius(dip2px(8));
        background.setColor(colorOff);
        background.setStroke((int) dip2px(1), Color.WHITE);
        linearLayout.setBackground(background);

        final TextView title = new TextView(activity);
        title.setText(string);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        title.setPadding(16, 16, 16, 16);
		
		title.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					if (!string.equals(null)) {
						JNICall JNICall = new JNICall();
						if (JNICall.getModuleEnabled(string)) {
							background.setColor(colorOff);
							linearLayout.setBackground(background);
							JNICall.setModuleEnabled(string, false);
						} else {
							background.setColor(colorOn);
							linearLayout.setBackground(background);
							JNICall.setModuleEnabled(string, true);
						}
					}
				}
			});

        final ab manager = new ab();

        title.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View view) {
					manager.onLongClick();
					return false;
				}
			});

        linearLayout.addView(title);
        final PopupWindow popupWindow = new PopupWindow(linearLayout, LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        popupWindow.showAtLocation(activity.getWindow().getDecorView(), Gravity.CENTER, 0, 0);

        title.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View view, MotionEvent event) {
					return manager.onTouch(view, event, popupWindow);
				}
			});
    }
	public static float dip2px(Object value){
        if (value instanceof Float){
            return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,(float) value, getSystem().getDisplayMetrics());
        }
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,(int)value, getSystem().getDisplayMetrics());
    }
    
}

