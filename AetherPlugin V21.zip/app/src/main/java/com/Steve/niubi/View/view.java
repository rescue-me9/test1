package com.Steve.niubi.View;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.Steve.niubi.Call.JNICall;
import com.Steve.niubi.GUI.Combat;
import com.Steve.niubi.GUI.Draw;
import com.Steve.niubi.GUI.Move;
import com.Steve.niubi.GUI.Player;
import com.Steve.niubi.GUI.World;
import com.Steve.niubi.GUI.quickly;
import com.Steve.niubi.Other;

public class view {
	private static LinearLayout layout1;
	private static ValueAnimator currentAnimator;
	private static int currentHeight = 0;

	public static LinearLayout createMenuView(final String[] menuItems, final int[] backgroundColors, int[] function, final Activity activity) {
		Context context = activity.getApplicationContext();
		int screenWidth = context.getResources().getDisplayMetrics().widthPixels;
		int width = (int) (screenWidth * 0.16);
		int width1 = (int) (screenWidth * 0.01);
		final JNICall JNICall = new JNICall();
		final LinearLayout layout = new LinearLayout(activity);
		layout.setOrientation(LinearLayout.VERTICAL);

		for (int i = 0; i < menuItems.length; i++) {
			final int a = i;
			final LinearLayout menuItemContainer = new LinearLayout(activity);
			menuItemContainer.setOrientation(LinearLayout.HORIZONTAL);
			menuItemContainer.setLayoutParams(new LinearLayout.LayoutParams(
												  LinearLayout.LayoutParams.MATCH_PARENT,
												  LinearLayout.LayoutParams.WRAP_CONTENT));
			menuItemContainer.setGravity(Gravity.CENTER_VERTICAL);
			menuItemContainer.setBackground(new ColorDrawable(backgroundColors[i]));

			TextView menuItemText = new TextView(activity);
			menuItemText.setText(menuItems[i]);
			menuItemText.setTextColor(Color.WHITE);
			menuItemText.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
			menuItemText.setPadding(16, 16, 16, 16);
			
			LinearLayout.LayoutParams arrowParams1 = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.MATCH_PARENT,
				1);
			menuItemText.setLayoutParams(arrowParams1);

			menuItemContainer.addView(menuItemText);

			layout.addView(menuItemContainer);

			/*
			 final TextView menuItemArrow = new TextView(activity);
			 menuItemArrow.setText("+");
			 menuItemArrow.setTextColor(Color.WHITE);
			 menuItemArrow.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
			 menuItemArrow.setPadding(16, 16, 16, 16);

			 LinearLayout.LayoutParams arrowParams1 = new LinearLayout.LayoutParams(
			 0,
			 LinearLayout.LayoutParams.MATCH_PARENT,
			 1);
			 menuItemArrow.setLayoutParams(arrowParams1);
			if (function[a] != 0) {
				if (!menuItemContainer.isInEditMode() && menuItemContainer.getChildAt(1) == null) {
					menuItemContainer.addView(menuItemArrow);
				}
				if (menuItems[a].equals("HitBox")) {
					layout1 = Functionlayout.HitBox_Layout(activity);
					layout.addView(layout1);
					layout1.setVisibility(View.GONE);
				}
			}

			menuItemText.setOnLongClickListener(new View.OnLongClickListener() {
					@Override
					public boolean onLongClick(View view) {
						if (menuItems[a] != null && menuItems[a].equals("HitBox")) {
							if (Functionlayout.HitBox) {
								collapseLinearLayout(layout1, layout1, 500);
								Functionlayout.HitBox = false;
								menuItemArrow.setText("+");
							} else {
								expandLinearLayout(layout1, 500);
								Functionlayout.HitBox = true;
								menuItemArrow.setText("-");
							}
						}
						return true;
					}
				});
				*/

			menuItemText.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View view) {
						if (menuItems[a] != null) {
							if (menuItems[a].equals("Combat")) {
								if (Other.Combat_bool) {
									Combat.b(activity);
									Other.Combat_bool = false;
									menuItemContainer.setBackgroundColor(backgroundColors[a]);
								} else {
									Combat.a(activity);
									Other.Combat_bool = true;
									menuItemContainer.setBackgroundColor(0x1AFFFFFF);
								}
							} else if (menuItems[a].equals("Move")) {
								if (Other.Move_bool) {
									Move.b(activity);
									Other.Move_bool = false;
									menuItemContainer.setBackgroundColor(backgroundColors[a]);
								} else {
									Move.a(activity);
									Other.Move_bool = true;
									menuItemContainer.setBackgroundColor(0x1AFFFFFF);
								}
							} else if (menuItems[a].equals("Player")) {
								if (Other.Player_bool) {
									Player.b(activity);
									Other.Player_bool = false;
									menuItemContainer.setBackgroundColor(backgroundColors[a]);
								} else {
									Player.a(activity);
									Other.Player_bool = true;
									menuItemContainer.setBackgroundColor(0x1AFFFFFF);
								}
							} else if (menuItems[a].equals("World")) {
								if (Other.World_bool) {
									World.b(activity);
									Other.World_bool = false;
									menuItemContainer.setBackgroundColor(backgroundColors[a]);
								} else {
									World.a(activity);
									Other.World_bool = true;
									menuItemContainer.setBackgroundColor(0x1AFFFFFF);
								}
							} else if (menuItems[a].equals("Draw")) {
								if (Other.Draw_bool) {
									Draw.b(activity);
									Other.Draw_bool = false;
									menuItemContainer.setBackgroundColor(backgroundColors[a]);
								} else {
									Draw.a(activity);
									Other.Draw_bool = true;
									menuItemContainer.setBackgroundColor(0x1AFFFFFF);
								}
							} else if (menuItems[a].equals("快捷键")) {
								quickly.a(activity);
							} else if (menuItems[a].equals("初始化")) {
								JNICall.InitializeModules();
								Toast.makeText(activity.getApplication(), "初始化", Toast.LENGTH_SHORT).show();
							} else {
								try {
									if (JNICall.getModuleEnabled(menuItems[a])) {
										menuItemContainer.setBackgroundColor(backgroundColors[a]);
										JNICall.setModuleEnabled(menuItems[a], false);
									} else {
										menuItemContainer.setBackgroundColor(0x1AFFFFFF);
										JNICall.setModuleEnabled(menuItems[a], true);
									}
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						}
					}
				});
		}

		return layout;
	}

	public static void expandLinearLayout(final LinearLayout linearLayout, int duration) {
		if (currentAnimator != null) {
			currentAnimator.cancel();
		}

		linearLayout.setVisibility(View.VISIBLE);

		linearLayout.measure(View.MeasureSpec.makeMeasureSpec(linearLayout.getWidth(), View.MeasureSpec.EXACTLY),
							 View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
		final int targetHeight = linearLayout.getMeasuredHeight();

		final LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) linearLayout.getLayoutParams();
		layoutParams.height = currentHeight;
		linearLayout.setLayoutParams(layoutParams);

		currentAnimator = ValueAnimator.ofInt(currentHeight, targetHeight);
		currentAnimator.setDuration(duration);
		currentAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
				@Override
				public void onAnimationUpdate(ValueAnimator valueAnimator) {
					int newHeight = (int) valueAnimator.getAnimatedValue();
					currentHeight = newHeight;
					layoutParams.height = newHeight;
					linearLayout.setLayoutParams(layoutParams);
				}
			});
		currentAnimator.start();
	}
	public static void collapseLinearLayout(final LinearLayout linearLayout, final LinearLayout parentLayout, int duration) {
		if (currentAnimator != null) {
			currentAnimator.cancel();
		}

		final int initialHeight = linearLayout.getHeight();

		currentAnimator = ValueAnimator.ofInt(initialHeight, 0);
		currentAnimator.setDuration(duration);
		currentAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
				@Override
				public void onAnimationUpdate(ValueAnimator valueAnimator) {
					int newHeight = (int) valueAnimator.getAnimatedValue();
					LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) linearLayout.getLayoutParams();
					layoutParams.height = newHeight;
					linearLayout.setLayoutParams(layoutParams);

					// 如果高度为0，设置为GONE并通知父布局重绘
					if (newHeight == 0) {
						linearLayout.setVisibility(View.GONE);
						parentLayout.requestLayout();
						parentLayout.invalidate();
					}
				}
			});
		currentAnimator.addListener(new AnimatorListenerAdapter() {
				@Override
				public void onAnimationEnd(Animator animation) {
					super.onAnimationEnd(animation);
					linearLayout.setVisibility(View.GONE);
					parentLayout.requestLayout();
					parentLayout.invalidate();
				}
			});
		currentAnimator.start();
	}
	
	
}
