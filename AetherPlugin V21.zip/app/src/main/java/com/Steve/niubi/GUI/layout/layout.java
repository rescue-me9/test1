package com.Steve.niubi.GUI.layout;

public class layout {
	
	// Menu
	public static String[] Menu_Name = {"Combat", "Move", "Player", "World", "Draw", "快捷键", "初始化"};
	public static int[] Menu_Color = {
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0xAA000000
	};
	public static int[] Menu_function = {
		0,
		0,
		0,
		0,
		0,
		0,
		0
	};
    
    // Combat
	public static String[] Combat_Name = {"TPAura", "RiptideAura", "HitBox"};
	public static int[] Combat_Color = {
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0x1A000000  
	};
	public static int[] Combat_function = {
		0,
		0,
		1,
		0,
		0,
		0
	};
	
	// Move
	public static String[] Move_Name = {"NoFallDamage", "Fly", "AirJump", "Wallpiercing", "ClickTeleport"};
	public static int[] Move_Color = {
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0x1A000000  
	};
	public static int[] Move_function = {
		1,
		0,
		0,
		0,
		0,
		0
	};
	
	// Player
	public static String[] Player_Name = {"PlayerTP", "Assassination"};
	public static int[] Player_Color = {
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0x1A000000  
	};
	public static int[] Player_function = {
		0,
		0,
		0,
		0,
		0,
		0
	};
	
	// World
	public static String[] World_Name = {"VoidRebound"};
	public static int[] World_Color = {
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0x1A000000  
	};
	public static int[] World_function = {
		0,
		0,
		0,
		0,
		0,
		0
	};
	
	// Draw
	public static String[] Draw_Name = {"FunctionDraw"};
	public static int[] Draw_Color = {
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0x1A000000,
		0x1A000000  
	};
	public static int[] Draw_function = {
		0,
		0,
		0,
		0,
		0,
		0
	};
}
