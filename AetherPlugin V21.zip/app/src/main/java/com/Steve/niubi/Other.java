package com.Steve.niubi;

public class Other {
	
	public static String Menu_width = "WRAP";
	public static String Combat_width = "WRAP";
	public static String Move_width = "WRAP";
	public static String Player_width = "WRAP";
	public static String World_width = "WRAP";
	public static String Draw_width = "WRAP";
	public static String quickly_width = "WRAP";

	public static String Menu_backgroundGradient_Top = "0x80cc99ff";
	public static String Combat_backgroundGradient_Top = "0x80cc99ff";
	public static String Move_backgroundGradient_Top = "0x80cc99ff";
	public static String Player_backgroundGradient_Top = "0x80cc99ff";
	public static String World_backgroundGradient_Top = "0x80cc99ff";
	public static String Draw_backgroundGradient_Top = "0x80cc99ff";
	public static String quickly_backgroundGradient_Top = "0x80cc99ff";

	public static String Menu_backgroundGradient_Bottom = "0x8087CEFA";
	public static String Combat_backgroundGradient_Bottom = "0x8087CEFA";
	public static String Move_backgroundGradient_Bottom = "0x8087CEFA";
	public static String Player_backgroundGradient_Bottom = "0x8087CEFA";
	public static String World_backgroundGradient_Bottom = "0x8087CEFA";
	public static String Draw_backgroundGradient_Bottom = "0x8087CEFA";
	public static String quickly_backgroundGradient_Bottom = "0x8087CEFA";
	
	
	
	
    
	// Menu
    public static float lastX; //上一次位置的X.Y坐标
	public static float lastY;
	public static float nowX;  //当前移动位置的X.Y坐标
	public static float nowY;
	public static float tranX; //悬浮窗移动位置的相对值
	public static float tranY;
	public static int opMPX;
	public static int opMPY;
	
	// Combat
    public static float Combat_lastX; //上一次位置的X.Y坐标
	public static float Combat_lastY;
	public static float Combat_nowX;  //当前移动位置的X.Y坐标
	public static float Combat_nowY;
	public static float Combat_tranX; //悬浮窗移动位置的相对值
	public static float Combat_tranY;
	public static int Combat_opMPX;
	public static int Combat_opMPY;
	
	// Move
	public static float Move_lastX; //上一次位置的X.Y坐标
	public static float Move_lastY;
	public static float Move_nowX;  //当前移动位置的X.Y坐标
	public static float Move_nowY;
	public static float Move_tranX; //悬浮窗移动位置的相对值
	public static float Move_tranY;
	public static int Move_opMPX;
	public static int Move_opMPY;
	
	// Player
	public static float Player_lastX; //上一次位置的X.Y坐标
	public static float Player_lastY;
	public static float Player_nowX;  //当前移动位置的X.Y坐标
	public static float Player_nowY;
	public static float Player_tranX; //悬浮窗移动位置的相对值
	public static float Player_tranY;
	public static int Player_opMPX;
	public static int Player_opMPY;
	
	// World
	public static float World_lastX; // 上一次位置的 X.Y 坐标
	public static float World_lastY;
	public static float World_nowX;  // 当前移动位置的 X.Y 坐标
	public static float World_nowY;
	public static float World_tranX; // 悬浮窗移动位置的相对值
	public static float World_tranY;
	public static int World_opMPX;
	public static int World_opMPY;
	
	// Draw
	public static float Draw_lastX; // 上一次位置的 X.Y 坐标
	public static float Draw_lastY;
	public static float Draw_nowX;  // 当前移动位置的 X.Y 坐标
	public static float Draw_nowY;
	public static float Draw_tranX; // 悬浮窗移动位置的相对值
	public static float Draw_tranY;
	public static int Draw_opMPX;
	public static int Draw_opMPY;
	
	// Extend
	public static float Extend_lastX; // 上一次位置的 X.Y 坐标
	public static float Extend_lastY;
	public static float Extend_nowX;  // 当前移动位置的 X.Y 坐标
	public static float Extend_nowY;
	public static float Extend_tranX; // 悬浮窗移动位置的相对值
	public static float Extend_tranY;
	public static int Extend_opMPX;
	public static int Extend_opMPY;
	
	
	public static boolean Combat_bool = false;
	public static boolean Move_bool = false;
	public static boolean Player_bool = false;
	public static boolean World_bool = false;
	public static boolean Draw_bool = false;
	public static boolean Extend_bool = false;
    
}
