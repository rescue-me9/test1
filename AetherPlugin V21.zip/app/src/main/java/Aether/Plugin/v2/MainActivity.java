package Aether.Plugin.v2;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {

    private EditText etAuthCode;
    private Button btnSubmit;
    private SharedPreferences prefs;
    private static final String PREF_NAME = "AetherAuth";
    private static final String KEY_AUTHED = "authed";
    private static final String AUTH_URL = "http://localhost:8080/auth.php"; // 改成你的

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etAuthCode = findViewById(R.id.et_auth_code);
        btnSubmit = findViewById(R.id.btn_submit);
        prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);

        if (prefs.getBoolean(KEY_AUTHED, false)) {
            loadCorePlugin();
        } else {
            hideFunctionUI();
            btnSubmit.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						String code = etAuthCode.getText().toString().trim();
						if (code.isEmpty()) {
							Toast.makeText(MainActivity.this, "请输入授权码", Toast.LENGTH_SHORT).show();
						} else {
							verifyAuthCode(code);
						}
					}
				});
        }
    }

    private void verifyAuthCode(final String code) {
        btnSubmit.setEnabled(false);
        btnSubmit.setText("验证中...");

        new Thread(new Runnable() {
				@Override
				public void run() {
					final boolean ok = sendAuthRequest(code);
					runOnUiThread(new Runnable() {
							@Override
							public void run() {
								btnSubmit.setEnabled(true);
								btnSubmit.setText("提交授权");
								if (ok) {
									prefs.edit().putBoolean(KEY_AUTHED, true).apply();
									Toast.makeText(MainActivity.this, "授权成功", Toast.LENGTH_SHORT).show();
									loadCorePlugin();
								} else {
									Toast.makeText(MainActivity.this, "授权码无效", Toast.LENGTH_SHORT).show();
								}
							}
						});
				}
			}).start();
    }

    private boolean sendAuthRequest(String code) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(AUTH_URL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(8000);

            JSONObject json = new JSONObject();
            json.put("code", code);
            String body = json.toString();

            DataOutputStream out = new DataOutputStream(conn.getOutputStream());
            out.writeBytes(body);
            out.flush();
            out.close();

            int respCode = conn.getResponseCode();
            if (respCode == 200) {
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                JSONObject result = new JSONObject(sb.toString());
                return result.optBoolean("success", false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (conn != null) conn.disconnect();
        }
        return false;
    }

    private void loadCorePlugin() {
        View functionContainer = findViewById(R.id.function_container);
        if (functionContainer != null) {
            functionContainer.setVisibility(View.VISIBLE);
        }
        // 在这里添加你的插件核心逻辑（例如启动功能）
    }

    private void hideFunctionUI() {
        View functionContainer = findViewById(R.id.function_container);
        if (functionContainer != null) {
            functionContainer.setVisibility(View.GONE);
        }
    }
}

